<?php
declare(strict_types=1);

class IndexController extends ControllerBase
{

    public function indexAction()
    {
        $warga = warga::find(['order' => 'id DESC']);
        $this->view->warga = $warga;
    }

}

