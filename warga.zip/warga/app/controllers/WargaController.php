<?php
declare(strict_types=1);

use Phalcon\Http\Response as Response;

class WargaController extends \Phalcon\Mvc\Controller
{

    public function indexAction()
    {
        
    }

    public function viewAction()
    {
        $warga = warga::find(['order' => 'id DESC']);
        $this->view->warga = $warga;
    }

    public function saveAction()
    {
        $this->view->disable();

        $res = new Response;

        $id = $this->request->getPost("id");

        if($id == ''){
            $create = new warga();

            $create->assign(array(
                'nama' => $this->request->getPost('nama'),
                'no_ktp' => $this->request->getPost('no_ktp')
            ));

            $action = $create->save();
        }else{
            $warga = warga::findFirst($id);

            $warga->id = $id;
            $warga->nama = $this->request->getPost("nama");
            $warga->no_ktp = $this->request->getPost("no_ktp");

            $action = $warga->save();
        }

        if(! $action){
            $return = array('return' => false, 'msg' => 'tidak tersimpan');
        }else{
            // $return = array('return' => true);
            $return = 1;
        }

        $res->setContent(json_encode($return));

        return $res;
    }

    public function editAction()
    {
        $this->view->disable();

        $res = new Response;

        $id = $this->request->getPost('id');
        $warga = warga::findFirst($id);

        $res->setContent( json_encode( array(
            'id'=>$warga->id,
            'nama'=>$warga->nama,
            'no_ktp'=>$warga->no_ktp
        ) ) );

        return $res;
    }

    public function deleteAction()
    {
        $this->view->disable();

        $res = new Response();

        $id = $this->request->getPost('id');
        $warga = warga::findFirst($id);

        if(! $warga->delete()){
            $return = array('return' => false, 'msg' => 'Tidak terhapus');
        }else{
            $return = array('return' => true);
        }

        $res->setContent(json_encode($return));

        return $res;
    }

    // public function addAction()
    // {
    //     $this->response->redirect('warga');
    // }

    // public function insertAction()
    // {
    //     $warga = new warga();
    //     $warga->nama = $this->request->getPost("nama");
    //     $warga->no_ktp = $this->request->getPost("no_ktp");

        


    //     // if (isset($_POST['nama']) AND isset($_POST['email']))
    //     // {
    //     // echo $_POST['nama'];
    //     // echo $_POST['email'];
    //     // }

    //     if (!$warga->Save()) {
    //         echo 0;
    //     }else{
    //         echo 1;
            
    //     }
    // }

    // public function viewAction()
    // {
    //     $warga = warga::find();
    //     $this->view->data=$warga;
    // }

    // public function editAction($id = null)
    // {
    //     // if (!isset($id)) {
    //     //     $this->response->redirect('warga/view');
    //     // }
        
    //     $warga = warga::findFirstByid($id);
    //     $this->view->id = $warga->id;
    //     $this->view->nama = $warga->nama;
    //     $this->view->no_ktp = $warga->no_ktp;
    // }

    // public function updateAction()
    // {
    //     $id = $this->request->getPost("id");
    //     $warga = warga::findFirstByid($id);
    //     $warga->nama = $this->request->getPost("nama");
    //     $warga->no_ktp = $this->request->getPost("no_ktp");

    //     // if (isset($_GET['id']) AND isset($_GET['nama']) AND isset($_GET['no_ktp']))
    //     // {
    //     //     echo $_GET['id'];
    //     //     echo $_GET['nama'];
    //     //     echo $_GET['no_ktp'];
    //     // }
        
    //     if (!$warga->Save()) {
    //         echo 0;
    //         }else{
    //         echo 1;
            
    //         // $this->response->redirect('warga/view');

    //         // return;
    //         //echo Phalcon\Tag::linkTo("warga/view", "Lihat Data");
    //     }
    // }

    // public function deleteAction($id)
    // {
    //     $warga = warga::findFirstByid($id);

    //     if (!$warga->delete()) {
    //     echo 0;
    //     }else{
    //     echo 1;
            
    //     // $this->response->redirect('warga/view');

    //     // return;
    //     //echo Phalcon\Tag::linkTo("warga/view", "Lihat Data");
    //     }
    // }

}