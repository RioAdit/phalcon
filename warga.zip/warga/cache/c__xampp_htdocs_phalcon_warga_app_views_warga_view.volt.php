<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="shortcut icon" href="#" />

    <title>Data Warga</title>

    <?= $this->tag->stylesheetLink('css/style.css') ?>
    <?= $this->tag->stylesheetLink('css/bootstrap.min.css') ?>
    <?= $this->tag->stylesheetLink('vendor/datatables/dataTables.bootstrap4.min.css') ?>
    <?= $this->tag->stylesheetLink('vendor/fontawesome-free/css/all.min.css') ?>
    <?= $this->tag->stylesheetLink('css/sb-admin-2.min.css') ?>
    <?= $this->tag->javascriptInclude('js/jquery-3.7.0.min.js') ?>
    <?= $this->tag->javascriptInclude('js/bootstrap.min.js') ?>
    

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script type="module" src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <?= $this->tag->javascriptInclude('js/function.js') ?>

</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3">Data Warga</div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Tables -->
            <li class="nav-item active">
                <a class="nav-link" href="<?= $this->url->get('warga') ?>">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Daftar Data Warga</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">

            <!-- Sidebar Toggler (Sidebar) -->
            <div class="text-center d-none d-md-inline">
                <button class="rounded-circle border-0" id="sidebarToggle"></button>
            </div>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <form class="form-inline">
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
                    </form>

                    <!-- Topbar Search -->
                    <form
                        class="d-none d-sm-inline-block form-inline mr-auto ml-md-3 my-2 my-md-0 mw-100 navbar-search">
                        <div class="input-group">
                            <input type="text" id="search" class="form-control bg-light border-0 small" placeholder="Search for..."
                                aria-label="Search" aria-describedby="basic-addon2">
                            <div class="input-group-append">
                                <button class="btn btn-primary" type="button">
                                    <i class="fas fa-search fa-sm"></i>
                                </button>
                            </div>
                        </div>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" id="search" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->

                <div class="container-fluid">

                    <div class="alert" tabindex="-1">

                    </div>

                    <div class="card shadow mb-4">

                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Data Warga RT 04</h6>
                        </div>
                    
                        <div class="card-body">
                            <div class="table-responsive">
                                
                                <a href="" class="tambah btn btn-primary mb-3" data-toggle="modal" data-target="#dataBaruModal"><i class="fas fa-file-alt"></i> Tambah Data</a>

                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nama</th>
                                            <th>No. KTP</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>ID</th>
                                            <th>Nama</th>
                                            <th>No. KTP</th>
                                            <th>Action</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php foreach ($warga as $w) { ?>
                                        <tr>
                                            <th scope="row"><?= $w->id ?></th>
                                            <td><?= $w->nama ?></td>
                                            <td><?= $w->no_ktp ?></td>
                                            <td>
                                                <a class='edit btn btn-info btn-small' id='editId' data-toggle='modal' data-id="<?= $w->id ?>">Edit</a>
                                                <a href='#deleteModal' class='btn btn-danger btn-small' id='deleteId' data-toggle='modal' data-id="<?= $w->id ?>">Delete</a>
                                            </td>
                                        </tr>
                                        <?php } ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                
                </div>
                <!-- /.container-fluid -->
                
                </div>
                <!-- End of Main Content -->
        
                <div class="modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title" id="judul"></h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        </div>
                        <div class="modal-body">
                            <div id="tampil_modal">

                            </div>
                        </div>
                        
                        </div>
                    </div>
                </div>

                <!-- Modal Tambah data baru-->
                <div class="modal fade" id="dataBaruModal" tabindex="-1" role="dialog" aria-labelledby="dataBaruModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="judul">Data Warga</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form id="tambah-data" action="" method="post" enctype="multipart/form-data" class="form-warga">
                                <div class="modal-body">
                                    <div class="form-group">
                                        <input type="hidden" id="id" name="id"></input>
                                        <input type="text" class="form-control form-control-user" id="nama" name="nama" placeholder="Masukkan Nama Warga" required>
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" id="no_ktp" name="no_ktp" placeholder="Masukkan Nomor KTP Warga" required>
                                    </div>
                                    </div>
                                    <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-ban"></i> Close</button>
                                    <button type="button" onclick="doSave()" name="simpan" class="btn btn-primary" id="btnsimpan" aria-label="Close"><i class="fas fa-plus-circle"></i> Save</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End of Modal Tambah Menu -->

                <!-- Modal Edit data-->
                <div class="modal fade" id="editDataModal" tabindex="-1" role="dialog" aria-labelledby="editDataModalLabel"
                    aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="judul">Edit Data Warga</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <form id="" action="" method="get" enctype="multipart/form-data" class="form-warga">
                                <div class="modal-body">
                                <input type="hidden" id="id" name="id">
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" id="nama" name="nama"
                                            placeholder="Masukkan Nama Warga">
                                    </div>
                                    <div class="form-group">
                                        <input type="text" class="form-control form-control-user" id="no_ktp" name="no_ktp"
                                            placeholder="Masukkan Nomor KTP Warga">
                                    </div>
                                </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-ban"></i>
                                        Close</button>
                                    <button type="button" onclick="" class="update btn btn-primary" id="btnupdate"><i class="fas fa-plus-circle"></i>Simpan</button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <!-- End of Modal Edit Menu -->

                <!-- Prompt Deletion -->
                <div class="modal fade" id="deleteModal" role="dialog">
                    <div class="modal-dialog modal-sm">
                      <div class="modal-content">
                        <div class="modal-header">
                          <h4 class="modal-title">Peringatan !</h4>
                          <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <div class="modal-body">
                            <input type="hidden" id="iddel" name="iddel">
                            <p>Yakin hapus data ini ?</p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-dismiss="modal">Tidak</button>
                            <button type="button" onclick="deleteWarga()" class="btn btn-primary">Ya</button>
                        </div>
                      </div>
                    </div>
                </div>
                <!-- Prompt Deletion -->

            <!-- Footer -->
            <footer class="sticky-footer bg-white">
                <div class="container my-auto">
                    <div class="copyright text-center my-auto">
                        <span>Copyright &copy; Your Website 2020</span>
                    </div>
                </div>
            </footer>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <?= $this->tag->javascriptInclude('vendor/jquery/jquery.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/bootstrap/js/bootstrap.bundle.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/jquery-easing/jquery.easing.min.js') ?>
    <?= $this->tag->javascriptInclude('js/sb-admin-2.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/datatables/jquery.dataTables.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/datatables/dataTables.bootstrap4.min.js') ?>
    <?= $this->tag->javascriptInclude('js/demo/datatables-demo.js') ?>
    <?= $this->tag->javascriptInclude('js/jquery.validate.min.js') ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

    <script>
    
    

    </script>

</body>

</html>


