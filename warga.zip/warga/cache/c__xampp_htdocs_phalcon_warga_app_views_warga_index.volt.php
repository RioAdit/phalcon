<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <link rel="shortcut icon" href="#" />

    <title>Data Warga</title>

    <?= $this->tag->stylesheetLink('css/style.css') ?>
    <?= $this->tag->stylesheetLink('css/bootstrap.min.css') ?>
    <?= $this->tag->stylesheetLink('vendor/datatables/dataTables.bootstrap4.min.css') ?>
    <?= $this->tag->stylesheetLink('vendor/fontawesome-free/css/all.min.css') ?>
    <?= $this->tag->stylesheetLink('css/sb-admin-2.min.css') ?>
    <?= $this->tag->javascriptInclude('js/jquery-3.7.0.min.js') ?>
    <?= $this->tag->javascriptInclude('js/bootstrap.min.js') ?>
    

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-4bw+/aepP/YC94hEpVNVgiZdgIC5+VKNBQNGCHeKRQN+PtmoHDEXuppvnDJzQIu9" crossorigin="anonymous">
    <script type="module" src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
    <?= $this->tag->javascriptInclude('js/function.js') ?>

    <script type="text/javascript">
    
    $(document).ready(function() {
        $.ajax({
            type: 'post',
            url: "/warga/view",
            cache: false,
            success: function(data) {
                $("#tampil").html(data);
            }
        });
    });

    </script>

</head>

<body id="page-top">
    <div id="tampil">
        
    </div>

    <?= $this->tag->javascriptInclude('vendor/jquery/jquery.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/bootstrap/js/bootstrap.bundle.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/jquery-easing/jquery.easing.min.js') ?>
    <?= $this->tag->javascriptInclude('js/sb-admin-2.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/datatables/jquery.dataTables.min.js') ?>
    <?= $this->tag->javascriptInclude('vendor/datatables/dataTables.bootstrap4.min.js') ?>
    <?= $this->tag->javascriptInclude('js/demo/datatables-demo.js') ?>
    <?= $this->tag->javascriptInclude('js/jquery.validate.min.js') ?>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-HwwvtgBNo3bZJJLYd8oVXjrBZt8cqVSpeBNS5n7C8IVInixGAoxmnlMuBnhbgrkm" crossorigin="anonymous"></script>

</body>
</html>