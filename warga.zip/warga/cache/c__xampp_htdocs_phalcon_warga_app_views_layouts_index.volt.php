<html> 
 <head>
  <title></title>
  
  <?= $this->tag->stylesheetLink('css/bootstrap.min.css') ?>
  <?= $this->tag->javascriptInclude('js/jquery-3.7.0.min.js') ?>
  <?= $this->tag->javascriptInclude('js/bootstrap.min.js') ?>
  
 </head>
 <body>
 <div id="tampil">

 </div>

 <!-- <nav id="myNavbar" class="navbar navbar-default navbar-inverse navbar-fixed-top" role="navigation">
     <div class="container-fluid">
         <div class="navbar-header">
             <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarCollapse">
                 <span class="sr-only">Toggle navigation</span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
             </button>
             <a class="navbar-brand" href="#"></a>
         </div>
         <div class="collapse navbar-collapse" id="navbarCollapse">
             <ul class="nav navbar-nav">
                 <li><a href="<?= $this->url->get('warga/index') ?>" >Warga</a></li>
                 
             </ul>
         </div>
     </div>
 </nav> -->
 
  
  
 </body>
</html>