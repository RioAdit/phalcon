a:3:{i:0;s:1125:"<html> 
 <head>
  <title></title>
  
  <?= $this->tag->stylesheetLink('css/bootstrap.min.css') ?>
  <?= $this->tag->javascriptInclude('js/jquery-3.7.0.min.js') ?>
  <?= $this->tag->javascriptInclude('js/bootstrap.min.js') ?>
  
 </head>
 <body>
 <nav id="myNavbar" class="navbar navbar-default navbar-inverse navbar-fixed-top" role="navigation">
     <div class="container-fluid">
         <div class="navbar-header">
             <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#navbarCollapse">
                 <span class="sr-only">Toggle navigation</span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
                 <span class="icon-bar"></span>
             </button>
             <a class="navbar-brand" href="#"></a>
         </div>
         <div class="collapse navbar-collapse" id="navbarCollapse">
             <ul class="nav navbar-nav">
                 <li><a href="<?= $this->url->get('warga/index') ?>" >Warga</a></li>
                 
             </ul>
         </div>
     </div>
 </nav>
  ";s:7:"content";a:1:{i:0;a:4:{s:4:"type";i:357;s:5:"value";s:4:"
  ";s:4:"file";s:58:"C:\XAMPP\htdocs\phalcon\warga/app/views/layouts/index.volt";s:4:"line";i:31;}}i:1;s:19:"
 </body>
</html>";}