<?= $this->tag->form(['warga/update', 'role' => 'form', 'id' => 'formedit']) ?>

<?php
// echo Phalcon\Tag::linkTo("warga/view", "kembali");
?>

<!-- <div class="mb-3">
  <input type="hidden" name="id" value=<?php echo $id ?>>
  <label for="nama" class="form-label">Nama</label>
  <input type="text" class="form-control" name="nama" value="<?php echo $nama ?>"><br>
  <label for="no_ktp" class="form-label">No. KTP</label>
  <input type="text" class="form-control" name="no_ktp" value="<?php echo $no_ktp ?>"><br>
  <div class="d-grid gap-2">
    <button type="submit" onclick="doEdit()" class="btn btn-primary">Simpan</button>
  </div>
</div> -->

<input type="hidden" name="id" value=<?php echo $id ?>>
<div class="form-group">
    <input type="text" class="form-control form-control-user" id="nama" name="nama" value="<?php echo $nama ?>" placeholder="Masukkan Nama Warga" required>
</div>
<div class="form-group">
    <input type="text" class="form-control form-control-user" id="no_ktp" name="no_ktp" value="<?php echo $no_ktp ?>" placeholder="Masukkan Nomor KTP Warga" required>
</div>
</div>
<div class="modal-footer">
    <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-ban"></i> Close</button>
    <button type="button" onclick="doEdit()" name="edit" class="btn btn-primary" id="btnedit" aria-label="Close"><i class="fas fa-plus-circle"></i> Simpan</button>
</div>

<?= $this->tag->endForm() ?>