-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 31, 2023 at 11:30 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 7.4.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mhs`
--

-- --------------------------------------------------------

--
-- Table structure for table `mahasiswa`
--

CREATE TABLE `mahasiswa` (
  `nim` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `alamat` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mahasiswa`
--

INSERT INTO `mahasiswa` (`nim`, `nama`, `alamat`) VALUES
(1, 'rio', 'depok'),
(7, 'sean', 'aceh'),
(8, 'sean', 'aceh'),
(9, 'sean', 'aceh'),
(10, 'aa', 'aa'),
(11, 'aa', 'aa'),
(12, 'aa', 'aa'),
(13, 'deni', 'adas'),
(14, 'deni', 'adas'),
(15, 'deni', 'adas'),
(16, 'ss', 'ss'),
(17, 'qq', 'qq'),
(19, 'yy', 'yy'),
(20, 'yy', 'yy'),
(23, 'rio', 'bogor');

-- --------------------------------------------------------

--
-- Table structure for table `warga`
--

CREATE TABLE `warga` (
  `id` int(10) NOT NULL,
  `nama` varchar(255) NOT NULL,
  `no_ktp` int(16) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `warga`
--

INSERT INTO `warga` (`id`, `nama`, `no_ktp`) VALUES
(49, 'a', 1),
(52, 'aaa', 2147483647),
(54, 'ajsd', 2147483647),
(56, 'ajsd', 2147483647),
(57, 'ajsd', 2147483647),
(58, 'ajsd', 2147483647),
(60, 'awd', 2147483647),
(61, 'sad', 2147483647),
(62, 'ads', 2147483647),
(63, 'asdw', 2147483647),
(64, 'asd', 2147483647),
(65, 'aaaass', 2147483647),
(66, 'asdasf', 2147483647),
(67, 'sss', 2147483647),
(68, 'sada', 123154),
(69, 'eee', 3443),
(70, 'aaa', 2147483647),
(71, 'aaa', 2147483647),
(72, 'aaass', 2147483647),
(73, '333', 2147483647),
(74, '222', 2147483647),
(75, '555', 2147483647),
(76, 'www', 2147483647),
(77, 'fff', 2147483647),
(78, 'aaa', 2147483647),
(79, 'sada', 2147483647),
(80, 'aaaaaaa', 2147483647),
(81, 'aaaaaaa', 2147483647),
(82, 'asd', 2147483647);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `warga`
--
ALTER TABLE `warga`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mahasiswa`
--
ALTER TABLE `mahasiswa`
  MODIFY `nim` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=25;

--
-- AUTO_INCREMENT for table `warga`
--
ALTER TABLE `warga`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
